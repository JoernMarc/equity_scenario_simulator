import React from 'react';

/**
 * A placeholder component. The original file was empty, which can cause build errors.
 */
const CapTableDisplay = () => {
  return null;
};

export default CapTableDisplay;
